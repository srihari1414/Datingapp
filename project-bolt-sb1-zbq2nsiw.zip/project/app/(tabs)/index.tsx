import React, { useState, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Dimensions,
  ScrollView,
  TouchableOpacity,
  Image,
  Animated,
  PanResponder,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { BlurView } from 'expo-blur';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Heart, X, Star, Zap, Settings } from 'lucide-react-native';
import GlassCard from '@/components/GlassCard';
import PrimaryButton from '@/components/PrimaryButton';

const { width, height } = Dimensions.get('window');

// Mock user data
const mockUsers = [
  {
    id: '1',
    name: 'Emma',
    age: 28,
    location: 'New York, NY',
    bio: 'Adventure seeker, coffee enthusiast, and dog lover. Always up for spontaneous trips and deep conversations.',
    images: ['https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg?auto=compress&cs=tinysrgb&w=600'],
    interests: ['Travel', 'Photography', 'Hiking', 'Coffee'],
    distance: '2 miles away',
  },
  {
    id: '2',
    name: 'Sophia',
    age: 26,
    location: 'Los Angeles, CA',
    bio: 'Yoga instructor by day, stargazer by night. Looking for someone who appreciates both quiet moments and grand adventures.',
    images: ['https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&w=600'],
    interests: ['Yoga', 'Astronomy', 'Art', 'Meditation'],
    distance: '5 miles away',
  },
  {
    id: '3',
    name: 'Isabella',
    age: 30,
    location: 'Chicago, IL',
    bio: 'Entrepreneur with a passion for sustainable living. Love trying new restaurants and exploring hidden gems in the city.',
    images: ['https://images.pexels.com/photos/1858175/pexels-photo-1858175.jpeg?auto=compress&cs=tinysrgb&w=600'],
    interests: ['Business', 'Sustainability', 'Food', 'Music'],
    distance: '1 mile away',
  },
];

export default function DiscoverScreen() {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [showActions, setShowActions] = useState(false);
  const pan = useRef(new Animated.ValueXY()).current;
  const scale = useRef(new Animated.Value(1)).current;

  const currentUser = mockUsers[currentIndex];

  const panResponder = PanResponder.create({
    onMoveShouldSetPanResponder: () => true,
    onPanResponderGrant: () => {
      pan.setOffset({
        x: pan.x._value,
        y: pan.y._value,
      });
      Animated.spring(scale, {
        toValue: 0.95,
        useNativeDriver: true,
      }).start();
    },
    onPanResponderMove: Animated.event([null, { dx: pan.x, dy: pan.y }], {
      useNativeDriver: true,
    }),
    onPanResponderRelease: (evt, gestureState) => {
      pan.flattenOffset();
      Animated.spring(scale, {
        toValue: 1,
        useNativeDriver: true,
      }).start();

      if (Math.abs(gestureState.dx) > 120) {
        const direction = gestureState.dx > 0 ? 'right' : 'left';
        handleSwipe(direction);
      } else {
        Animated.spring(pan, {
          toValue: { x: 0, y: 0 },
          useNativeDriver: true,
        }).start();
      }
    },
  });

  const handleSwipe = (direction: 'left' | 'right') => {
    const toValue = direction === 'right' ? width : -width;
    
    Animated.timing(pan, {
      toValue: { x: toValue, y: 0 },
      duration: 250,
      useNativeDriver: true,
    }).start(() => {
      // Reset the card position and update index
      Animated.spring(pan, {
        toValue: { x: 0, y: 0 },
        duration: 0,
        useNativeDriver: true,
      }).start(() => {
        setCurrentIndex((prev) => (prev + 1) % mockUsers.length);
      });
    });
  };

  const handleAction = (action: 'pass' | 'like' | 'superlike') => {
    if (action === 'like') {
      handleSwipe('right');
    } else if (action === 'pass') {
      handleSwipe('left');
    } else {
      // Super like animation
      Animated.sequence([
        Animated.timing(scale, {
          toValue: 1.1,
          duration: 150,
          useNativeDriver: true,
        }),
        Animated.timing(scale, {
          toValue: 1,
          duration: 150,
          useNativeDriver: true,
        }),
      ]).start();
    }
  };

  if (!currentUser) {
    return (
      <View style={styles.container}>
        <LinearGradient 
          colors={['#0F0F23', '#1A1A2E', '#16213E', '#0F3460']} 
          style={styles.liquidGlassBackground}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
        />
        <View style={styles.glassOverlay} />
        <SafeAreaView style={styles.safeArea}>
          <GlassCard style={styles.emptyCard}>
            <Text style={styles.emptyText}>No more profiles to show</Text>
            <Text style={styles.emptySubtext}>Check back later for new matches!</Text>
          </GlassCard>
        </SafeAreaView>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <LinearGradient 
        colors={['#0F0F23', '#1A1A2E', '#16213E', '#0F3460']} 
        style={styles.liquidGlassBackground}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
      />
      <View style={styles.glassOverlay} />
      <SafeAreaView style={styles.safeArea}>
        {/* Header */}
        <View style={styles.header}>
          <Text style={styles.headerTitle}>Swingerrr</Text>
          <TouchableOpacity style={styles.settingsButton}>
            <Settings size={24} color="#8B5CF6" />
          </TouchableOpacity>
        </View>

        {/* Card Stack */}
        <View style={styles.cardContainer}>
          <Animated.View
            style={[
              styles.card,
              {
                transform: [
                  { translateX: pan.x },
                  { translateY: pan.y },
                  { scale: scale },
                ],
              },
            ]}
            {...panResponder.panHandlers}
          >
            <TouchableOpacity
              activeOpacity={0.9}
              onPress={() => setShowActions(!showActions)}
              style={styles.cardTouchable}
            >
              <GlassCard style={styles.profileCard}>
                <Image source={{ uri: currentUser.images[0] }} style={styles.profileImage} />
                <LinearGradient
                  colors={['transparent', 'rgba(0,0,0,0.8)']}
                  style={styles.profileGradient}
                />
                <View style={styles.profileInfo}>
                  <Text style={styles.profileName}>
                    {currentUser.name}, {currentUser.age}
                  </Text>
                  <Text style={styles.profileLocation}>{currentUser.distance}</Text>
                  <Text style={styles.profileBio} numberOfLines={3}>
                    {currentUser.bio}
                  </Text>
                  <ScrollView
                    horizontal
                    showsHorizontalScrollIndicator={false}
                    style={styles.interestsContainer}
                  >
                    {currentUser.interests.map((interest, index) => (
                      <BlurView key={index} intensity={20} style={styles.interestTag}>
                        <Text style={styles.interestText}>{interest}</Text>
                      </BlurView>
                    ))}
                  </ScrollView>
                </View>
              </GlassCard>
            </TouchableOpacity>
          </Animated.View>
        </View>

        {/* Action Buttons */}
        <View style={styles.actionsContainer}>
          <TouchableOpacity
            style={[styles.actionButton, styles.passButton]}
            onPress={() => handleAction('pass')}
          >
            <X size={28} color="#EF4444" />
          </TouchableOpacity>
          
          <TouchableOpacity
            style={[styles.actionButton, styles.superLikeButton]}
            onPress={() => handleAction('superlike')}
          >
            <Star size={24} color="#0EA5E9" />
          </TouchableOpacity>
          
          <TouchableOpacity
            style={[styles.actionButton, styles.likeButton]}
            onPress={() => handleAction('like')}
          >
            <Heart size={28} color="#EC4899" />
          </TouchableOpacity>
        </View>

        {/* Boost Button */}
        <View style={styles.boostContainer}>
          <PrimaryButton
            title="Boost Profile"
            onPress={() => {}}
            style={styles.boostButton}
            icon={<Zap size={20} color="#FFFFFF" />}
          />
        </View>
      </SafeAreaView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    position: 'relative',
  },
  liquidGlassBackground: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    zIndex: -2,
  },
  glassOverlay: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'rgba(255, 255, 255, 0.02)',
    backdropFilter: 'blur(20px)',
    zIndex: -1,
  },
  safeArea: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingVertical: 15,
  },
  headerTitle: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#FFFFFF',
    textShadowColor: 'rgba(139, 92, 246, 0.5)',
    textShadowOffset: { width: 0, height: 2 },
    textShadowRadius: 4,
  },
  settingsButton: {
    padding: 8,
  },
  cardContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 20,
  },
  card: {
    width: width - 40,
    height: height * 0.7,
  },
  cardTouchable: {
    flex: 1,
  },
  profileCard: {
    flex: 1,
    overflow: 'hidden',
    position: 'relative',
  },
  profileImage: {
    width: '100%',
    height: '100%',
    resizeMode: 'cover',
  },
  profileGradient: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    height: '50%',
  },
  profileInfo: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    padding: 20,
  },
  profileName: {
    fontSize: 32,
    fontWeight: 'bold',
    color: '#FFFFFF',
    marginBottom: 5,
  },
  profileLocation: {
    fontSize: 16,
    color: '#D1D5DB',
    marginBottom: 10,
  },
  profileBio: {
    fontSize: 16,
    color: '#F3F4F6',
    lineHeight: 22,
    marginBottom: 15,
  },
  interestsContainer: {
    flexDirection: 'row',
  },
  interestTag: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 20,
    marginRight: 8,
    backgroundColor: 'rgba(139, 92, 246, 0.2)',
    borderWidth: 1,
    borderColor: 'rgba(139, 92, 246, 0.3)',
  },
  interestText: {
    color: '#FFFFFF',
    fontSize: 12,
    fontWeight: '600',
  },
  actionsContainer: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingVertical: 20,
  },
  actionButton: {
    width: 60,
    height: 60,
    borderRadius: 30,
    justifyContent: 'center',
    alignItems: 'center',
    marginHorizontal: 15,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 8,
  },
  passButton: {
    backgroundColor: 'rgba(239, 68, 68, 0.1)',
    borderWidth: 2,
    borderColor: 'rgba(239, 68, 68, 0.3)',
  },
  superLikeButton: {
    backgroundColor: 'rgba(14, 165, 233, 0.1)',
    borderWidth: 2,
    borderColor: 'rgba(14, 165, 233, 0.3)',
    width: 50,
    height: 50,
    borderRadius: 25,
  },
  likeButton: {
    backgroundColor: 'rgba(236, 72, 153, 0.1)',
    borderWidth: 2,
    borderColor: 'rgba(236, 72, 153, 0.3)',
  },
  boostContainer: {
    paddingHorizontal: 20,
    paddingBottom: 20,
  },
  boostButton: {
    backgroundColor: 'rgba(139, 92, 246, 0.2)',
    borderWidth: 1,
    borderColor: 'rgba(139, 92, 246, 0.4)',
  },
  emptyCard: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    marginHorizontal: 20,
  },
  emptyText: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#FFFFFF',
    textAlign: 'center',
    marginBottom: 10,
  },
  emptySubtext: {
    fontSize: 16,
    color: '#9CA3AF',
    textAlign: 'center',
  },
});