import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Image,
  TextInput,
  KeyboardAvoidingView,
  Platform,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Send, ArrowLeft, Phone, Video, MoveHorizontal as MoreHorizontal, Clock } from 'lucide-react-native';
import GlassCard from '@/components/GlassCard';

// Mock chat data
const mockChat = {
  id: '1',
  name: 'Emma',
  image: 'https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg?auto=compress&cs=tinysrgb&w=600',
  isOnline: true,
  timeRemaining: '22h 15m',
  messages: [
    {
      id: '1',
      text: 'Hey! How was your weekend?',
      sender: 'other',
      timestamp: '2:30 PM',
    },
    {
      id: '2',
      text: 'It was great! Went hiking with some friends. How about you?',
      sender: 'me',
      timestamp: '2:32 PM',
    },
    {
      id: '3',
      text: 'That sounds amazing! I love hiking too. Which trail did you go to?',
      sender: 'other',
      timestamp: '2:35 PM',
    },
    {
      id: '4',
      text: 'We went to Bear Mountain. The views were incredible!',
      sender: 'me',
      timestamp: '2:37 PM',
    },
    {
      id: '5',
      text: 'I\'ve been wanting to check that out! Maybe we could plan a hike together sometime? 🥾',
      sender: 'other',
      timestamp: '2:40 PM',
    },
  ],
};

export default function ChatScreen() {
  const [message, setMessage] = useState('');
  const [showChat, setShowChat] = useState(false);

  const handleSend = () => {
    if (message.trim()) {
      setMessage('');
      // Add message sending logic here
    }
  };

  if (!showChat) {
    return (
      <LinearGradient colors={['#111827', '#1F2937']} style={styles.container}>
        <SafeAreaView style={styles.safeArea}>
          <View style={styles.header}>
            <Text style={styles.headerTitle}>Messages</Text>
          </View>
          
          <ScrollView style={styles.content}>
            <TouchableOpacity
              style={styles.chatPreview}
              onPress={() => setShowChat(true)}
            >
              <GlassCard style={styles.chatPreviewCard}>
                <View style={styles.chatPreviewInfo}>
                  <View style={styles.avatarContainer}>
                    <Image source={{ uri: mockChat.image }} style={styles.avatar} />
                    <View style={styles.onlineIndicator} />
                  </View>
                  <View style={styles.chatDetails}>
                    <Text style={styles.chatName}>{mockChat.name}</Text>
                    <Text style={styles.lastMessage}>
                      {mockChat.messages[mockChat.messages.length - 1].text}
                    </Text>
                    <View style={styles.timerContainer}>
                      <Clock size={12} color="#F59E0B" />
                      <Text style={styles.timerText}>{mockChat.timeRemaining} left</Text>
                    </View>
                  </View>
                </View>
                <Text style={styles.chatTime}>
                  {mockChat.messages[mockChat.messages.length - 1].timestamp}
                </Text>
              </GlassCard>
            </TouchableOpacity>
          </ScrollView>
        </SafeAreaView>
      </LinearGradient>
    );
  }

  return (
    <LinearGradient colors={['#111827', '#1F2937']} style={styles.container}>
      <SafeAreaView style={styles.safeArea}>
        <KeyboardAvoidingView 
          style={styles.chatContainer}
          behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        >
          {/* Chat Header */}
          <View style={styles.chatHeader}>
            <TouchableOpacity 
              onPress={() => setShowChat(false)}
              style={styles.backButton}
            >
              <ArrowLeft size={24} color="#FFFFFF" />
            </TouchableOpacity>
            
            <View style={styles.chatHeaderInfo}>
              <View style={styles.chatAvatarContainer}>
                <Image source={{ uri: mockChat.image }} style={styles.chatAvatar} />
                <View style={styles.chatOnlineIndicator} />
              </View>
              <View>
                <Text style={styles.chatHeaderName}>{mockChat.name}</Text>
                <View style={styles.chatTimerContainer}>
                  <Clock size={12} color="#F59E0B" />
                  <Text style={styles.chatTimerText}>{mockChat.timeRemaining} left</Text>
                </View>
              </View>
            </View>
            
            <View style={styles.chatHeaderActions}>
              <TouchableOpacity style={styles.chatActionButton}>
                <Phone size={20} color="#8B5CF6" />
              </TouchableOpacity>
              <TouchableOpacity style={styles.chatActionButton}>
                <Video size={20} color="#8B5CF6" />
              </TouchableOpacity>
              <TouchableOpacity style={styles.chatActionButton}>
                <MoreHorizontal size={20} color="#8B5CF6" />
              </TouchableOpacity>
            </View>
          </View>

          {/* Messages */}
          <ScrollView style={styles.messagesContainer} showsVerticalScrollIndicator={false}>
            {mockChat.messages.map((msg) => (
              <View
                key={msg.id}
                style={[
                  styles.messageContainer,
                  msg.sender === 'me' ? styles.myMessage : styles.otherMessage
                ]}
              >
                <GlassCard
                  style={[
                    styles.messageBubble,
                    msg.sender === 'me' ? styles.myBubble : styles.otherBubble
                  ]}
                >
                  <Text style={styles.messageText}>{msg.text}</Text>
                  <Text style={styles.messageTime}>{msg.timestamp}</Text>
                </GlassCard>
              </View>
            ))}
          </ScrollView>

          {/* Message Input */}
          <View style={styles.inputContainer}>
            <GlassCard style={styles.inputCard}>
              <TextInput
                style={styles.textInput}
                placeholder="Type a message..."
                placeholderTextColor="#9CA3AF"
                value={message}
                onChangeText={setMessage}
                multiline
              />
              <TouchableOpacity
                style={[
                  styles.sendButton,
                  message.trim() ? styles.sendButtonActive : styles.sendButtonInactive
                ]}
                onPress={handleSend}
                disabled={!message.trim()}
              >
                <Send size={18} color={message.trim() ? "#FFFFFF" : "#6B7280"} />
              </TouchableOpacity>
            </GlassCard>
          </View>
        </KeyboardAvoidingView>
      </SafeAreaView>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  safeArea: {
    flex: 1,
  },
  header: {
    paddingHorizontal: 20,
    paddingVertical: 15,
  },
  headerTitle: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#FFFFFF',
  },
  content: {
    flex: 1,
    paddingHorizontal: 20,
  },
  chatPreview: {
    marginBottom: 12,
  },
  chatPreviewCard: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: 16,
  },
  chatPreviewInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  avatarContainer: {
    position: 'relative',
  },
  avatar: {
    width: 60,
    height: 60,
    borderRadius: 30,
    marginRight: 15,
  },
  onlineIndicator: {
    position: 'absolute',
    bottom: 2,
    right: 17,
    width: 12,
    height: 12,
    borderRadius: 6,
    backgroundColor: '#10B981',
    borderWidth: 2,
    borderColor: '#111827',
  },
  chatDetails: {
    flex: 1,
  },
  chatName: {
    fontSize: 18,
    fontWeight: '600',
    color: '#FFFFFF',
    marginBottom: 4,
  },
  lastMessage: {
    fontSize: 14,
    color: '#9CA3AF',
    marginBottom: 4,
  },
  timerContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  timerText: {
    fontSize: 12,
    color: '#F59E0B',
    marginLeft: 4,
    fontWeight: '600',
  },
  chatTime: {
    fontSize: 12,
    color: '#6B7280',
  },
  chatContainer: {
    flex: 1,
  },
  chatHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingVertical: 15,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(139, 92, 246, 0.2)',
  },
  backButton: {
    padding: 8,
  },
  chatHeaderInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
    marginLeft: 10,
  },
  chatAvatarContainer: {
    position: 'relative',
    marginRight: 12,
  },
  chatAvatar: {
    width: 40,
    height: 40,
    borderRadius: 20,
  },
  chatOnlineIndicator: {
    position: 'absolute',
    bottom: 0,
    right: 0,
    width: 10,
    height: 10,
    borderRadius: 5,
    backgroundColor: '#10B981',
    borderWidth: 2,
    borderColor: '#111827',
  },
  chatHeaderName: {
    fontSize: 18,
    fontWeight: '600',
    color: '#FFFFFF',
    marginBottom: 2,
  },
  chatTimerContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  chatTimerText: {
    fontSize: 12,
    color: '#F59E0B',
    marginLeft: 4,
    fontWeight: '600',
  },
  chatHeaderActions: {
    flexDirection: 'row',
  },
  chatActionButton: {
    padding: 8,
    marginLeft: 8,
  },
  messagesContainer: {
    flex: 1,
    paddingHorizontal: 20,
    paddingVertical: 10,
  },
  messageContainer: {
    marginVertical: 4,
  },
  myMessage: {
    alignItems: 'flex-end',
  },
  otherMessage: {
    alignItems: 'flex-start',
  },
  messageBubble: {
    maxWidth: '80%',
    padding: 12,
  },
  myBubble: {
    backgroundColor: 'rgba(139, 92, 246, 0.3)',
    borderWidth: 1,
    borderColor: 'rgba(139, 92, 246, 0.4)',
  },
  otherBubble: {
    backgroundColor: 'rgba(31, 41, 55, 0.8)',
    borderWidth: 1,
    borderColor: 'rgba(75, 85, 99, 0.3)',
  },
  messageText: {
    fontSize: 16,
    color: '#FFFFFF',
    marginBottom: 4,
  },
  messageTime: {
    fontSize: 12,
    color: '#9CA3AF',
    alignSelf: 'flex-end',
  },
  inputContainer: {
    paddingHorizontal: 20,
    paddingVertical: 15,
  },
  inputCard: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    padding: 12,
  },
  textInput: {
    flex: 1,
    color: '#FFFFFF',
    fontSize: 16,
    maxHeight: 100,
    marginRight: 10,
  },
  sendButton: {
    width: 36,
    height: 36,
    borderRadius: 18,
    justifyContent: 'center',
    alignItems: 'center',
  },
  sendButtonActive: {
    backgroundColor: '#8B5CF6',
  },
  sendButtonInactive: {
    backgroundColor: 'rgba(107, 114, 128, 0.3)',
  },
});