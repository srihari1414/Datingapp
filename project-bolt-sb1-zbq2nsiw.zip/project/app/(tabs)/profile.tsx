import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Image,
  Switch,
  Alert,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { BlurView } from 'expo-blur';
import { SafeAreaView } from 'react-native-safe-area-context';
import { CreditCard as Edit, Settings, Crown, Shield, Bell, MapPin, Heart, Star, CircleHelp as HelpCircle, LogOut, Camera, Plus } from 'lucide-react-native';
import GlassCard from '@/components/GlassCard';
import PrimaryButton from '@/components/PrimaryButton';

// Mock user profile data
const userProfile = {
  name: 'You',
  age: 25,
  location: 'San Francisco, CA',
  bio: 'Adventure seeker, coffee enthusiast, and dog lover. Always up for spontaneous trips and deep conversations.',
  images: [
    'https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg?auto=compress&cs=tinysrgb&w=600',
    'https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&w=600',
  ],
  interests: ['Travel', 'Photography', 'Hiking', 'Coffee', 'Art', 'Music'],
  stats: {
    matches: 127,
    likes: 89,
    superLikes: 12,
  },
};

export default function ProfileScreen() {
  const [notifications, setNotifications] = useState(true);
  const [showOnline, setShowOnline] = useState(true);
  const [incognitoMode, setIncognitoMode] = useState(false);

  const handleEditProfile = () => {
    Alert.alert('Edit Profile', 'Profile editing feature coming soon!');
  };

  const handlePremium = () => {
    Alert.alert('Premium', 'Upgrade to premium for exclusive features!');
  };

  const handleLogout = () => {
    Alert.alert('Logout', 'Are you sure you want to logout?', [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Logout', style: 'destructive', onPress: () => {} },
    ]);
  };

  const renderSettingItem = (
    icon: React.ReactNode,
    title: string,
    subtitle?: string,
    onPress?: () => void,
    showSwitch?: boolean,
    switchValue?: boolean,
    onSwitchChange?: (value: boolean) => void
  ) => (
    <TouchableOpacity
      style={styles.settingItem}
      onPress={onPress}
      disabled={showSwitch}
    >
      <GlassCard style={styles.settingCard}>
        <View style={styles.settingLeft}>
          <View style={styles.settingIcon}>{icon}</View>
          <View style={styles.settingText}>
            <Text style={styles.settingTitle}>{title}</Text>
            {subtitle && <Text style={styles.settingSubtitle}>{subtitle}</Text>}
          </View>
        </View>
        {showSwitch && (
          <Switch
            value={switchValue}
            onValueChange={onSwitchChange}
            trackColor={{ false: '#374151', true: '#8B5CF6' }}
            thumbColor={switchValue ? '#FFFFFF' : '#9CA3AF'}
          />
        )}
      </GlassCard>
    </TouchableOpacity>
  );

  return (
    <LinearGradient colors={['#111827', '#1F2937']} style={styles.container}>
      <SafeAreaView style={styles.safeArea}>
        <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
          {/* Header */}
          <View style={styles.header}>
            <Text style={styles.headerTitle}>Profile</Text>
            <TouchableOpacity style={styles.settingsButton}>
              <Settings size={24} color="#8B5CF6" />
            </TouchableOpacity>
          </View>

          {/* Profile Card */}
          <View style={styles.profileSection}>
            <GlassCard style={styles.profileCard}>
              <View style={styles.profileHeader}>
                <View style={styles.profileImageContainer}>
                  <Image source={{ uri: userProfile.images[0] }} style={styles.profileImage} />
                  <TouchableOpacity style={styles.editImageButton}>
                    <Camera size={16} color="#FFFFFF" />
                  </TouchableOpacity>
                </View>
                <View style={styles.profileInfo}>
                  <Text style={styles.profileName}>{userProfile.name}, {userProfile.age}</Text>
                  <Text style={styles.profileLocation}>{userProfile.location}</Text>
                  <TouchableOpacity style={styles.editButton} onPress={handleEditProfile}>
                    <Edit size={16} color="#8B5CF6" />
                    <Text style={styles.editButtonText}>Edit Profile</Text>
                  </TouchableOpacity>
                </View>
              </View>

              {/* Stats */}
              <View style={styles.statsContainer}>
                <View style={styles.statItem}>
                  <Text style={styles.statNumber}>{userProfile.stats.matches}</Text>
                  <Text style={styles.statLabel}>Matches</Text>
                </View>
                <View style={styles.statItem}>
                  <Text style={styles.statNumber}>{userProfile.stats.likes}</Text>
                  <Text style={styles.statLabel}>Likes</Text>
                </View>
                <View style={styles.statItem}>
                  <Text style={styles.statNumber}>{userProfile.stats.superLikes}</Text>
                  <Text style={styles.statLabel}>Super Likes</Text>
                </View>
              </View>

              {/* Bio */}
              <Text style={styles.profileBio}>{userProfile.bio}</Text>

              {/* Interests */}
              <View style={styles.interestsContainer}>
                {userProfile.interests.map((interest, index) => (
                  <BlurView key={index} intensity={20} style={styles.interestTag}>
                    <Text style={styles.interestText}>{interest}</Text>
                  </BlurView>
                ))}
              </View>

              {/* Photo Grid */}
              <View style={styles.photoGrid}>
                {userProfile.images.map((image, index) => (
                  <View key={index} style={styles.photoItem}>
                    <Image source={{ uri: image }} style={styles.photoImage} />
                  </View>
                ))}
                <TouchableOpacity style={styles.addPhotoButton}>
                  <Plus size={24} color="#8B5CF6" />
                </TouchableOpacity>
              </View>
            </GlassCard>
          </View>

          {/* Premium Banner */}
          <View style={styles.premiumBanner}>
            <TouchableOpacity onPress={handlePremium}>
              <GlassCard style={styles.premiumCard}>
                <LinearGradient
                  colors={['rgba(255, 215, 0, 0.2)', 'rgba(139, 92, 246, 0.2)']}
                  style={styles.premiumGradient}
                >
                  <Crown size={24} color="#FFD700" />
                  <Text style={styles.premiumTitle}>Upgrade to Premium</Text>
                  <Text style={styles.premiumSubtitle}>
                    Unlock unlimited likes, see who likes you, and more!
                  </Text>
                </LinearGradient>
              </GlassCard>
            </TouchableOpacity>
          </View>

          {/* Settings */}
          <View style={styles.settingsSection}>
            <Text style={styles.sectionTitle}>Settings</Text>
            
            {renderSettingItem(
              <Bell size={20} color="#8B5CF6" />,
              'Notifications',
              'Push notifications for new matches and messages',
              undefined,
              true,
              notifications,
              setNotifications
            )}

            {renderSettingItem(
              <MapPin size={20} color="#8B5CF6" />,
              'Show me online',
              'Let others see when you\'re active',
              undefined,
              true,
              showOnline,
              setShowOnline
            )}

            {renderSettingItem(
              <Shield size={20} color="#8B5CF6" />,
              'Incognito Mode',
              'Browse privately without being seen',
              undefined,
              true,
              incognitoMode,
              setIncognitoMode
            )}

            {renderSettingItem(
              <Heart size={20} color="#EC4899" />,
              'Safety Center',
              'Report users and safety tips',
              () => Alert.alert('Safety Center', 'Safety features coming soon!')
            )}

            {renderSettingItem(
              <Star size={20} color="#FFD700" />,
              'Rate Swingerrr',
              'Help us improve the app',
              () => Alert.alert('Rate App', 'Thanks for your feedback!')
            )}

            {renderSettingItem(
              <HelpCircle size={20} color="#8B5CF6" />,
              'Help & Support',
              'Get help with your account',
              () => Alert.alert('Help', 'Support page coming soon!')
            )}

            {renderSettingItem(
              <LogOut size={20} color="#EF4444" />,
              'Logout',
              'Sign out of your account',
              handleLogout
            )}
          </View>
        </ScrollView>
      </SafeAreaView>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  safeArea: {
    flex: 1,
  },
  content: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingVertical: 15,
  },
  headerTitle: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#FFFFFF',
  },
  settingsButton: {
    padding: 8,
  },
  profileSection: {
    paddingHorizontal: 20,
    marginBottom: 20,
  },
  profileCard: {
    padding: 20,
  },
  profileHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 20,
  },
  profileImageContainer: {
    position: 'relative',
    marginRight: 15,
  },
  profileImage: {
    width: 80,
    height: 80,
    borderRadius: 40,
  },
  editImageButton: {
    position: 'absolute',
    bottom: 0,
    right: 0,
    backgroundColor: '#8B5CF6',
    borderRadius: 12,
    width: 24,
    height: 24,
    justifyContent: 'center',
    alignItems: 'center',
  },
  profileInfo: {
    flex: 1,
  },
  profileName: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#FFFFFF',
    marginBottom: 4,
  },
  profileLocation: {
    fontSize: 16,
    color: '#9CA3AF',
    marginBottom: 10,
  },
  editButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(139, 92, 246, 0.2)',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 20,
    borderWidth: 1,
    borderColor: 'rgba(139, 92, 246, 0.3)',
    alignSelf: 'flex-start',
  },
  editButtonText: {
    color: '#8B5CF6',
    fontSize: 14,
    fontWeight: '600',
    marginLeft: 4,
  },
  statsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    marginBottom: 20,
    paddingVertical: 15,
    borderTopWidth: 1,
    borderBottomWidth: 1,
    borderColor: 'rgba(139, 92, 246, 0.2)',
  },
  statItem: {
    alignItems: 'center',
  },
  statNumber: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#FFFFFF',
    marginBottom: 4,
  },
  statLabel: {
    fontSize: 14,
    color: '#9CA3AF',
  },
  profileBio: {
    fontSize: 16,
    color: '#D1D5DB',
    lineHeight: 22,
    marginBottom: 20,
  },
  interestsContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    marginBottom: 20,
  },
  interestTag: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 20,
    marginRight: 8,
    marginBottom: 8,
    backgroundColor: 'rgba(139, 92, 246, 0.2)',
    borderWidth: 1,
    borderColor: 'rgba(139, 92, 246, 0.3)',
  },
  interestText: {
    color: '#FFFFFF',
    fontSize: 12,
    fontWeight: '600',
  },
  photoGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
  photoItem: {
    width: '48%',
    aspectRatio: 1,
    marginBottom: 10,
    borderRadius: 12,
    overflow: 'hidden',
  },
  photoImage: {
    width: '100%',
    height: '100%',
    resizeMode: 'cover',
  },
  addPhotoButton: {
    width: '48%',
    aspectRatio: 1,
    backgroundColor: 'rgba(139, 92, 246, 0.2)',
    borderWidth: 2,
    borderColor: 'rgba(139, 92, 246, 0.3)',
    borderStyle: 'dashed',
    borderRadius: 12,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 10,
  },
  premiumBanner: {
    paddingHorizontal: 20,
    marginBottom: 20,
  },
  premiumCard: {
    overflow: 'hidden',
  },
  premiumGradient: {
    padding: 20,
    alignItems: 'center',
  },
  premiumTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#FFFFFF',
    marginTop: 8,
    marginBottom: 4,
  },
  premiumSubtitle: {
    fontSize: 14,
    color: '#D1D5DB',
    textAlign: 'center',
  },
  settingsSection: {
    paddingHorizontal: 20,
    paddingBottom: 20,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#FFFFFF',
    marginBottom: 15,
  },
  settingItem: {
    marginBottom: 12,
  },
  settingCard: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: 16,
  },
  settingLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  settingIcon: {
    marginRight: 15,
  },
  settingText: {
    flex: 1,
  },
  settingTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#FFFFFF',
    marginBottom: 2,
  },
  settingSubtitle: {
    fontSize: 14,
    color: '#9CA3AF',
  },
});