import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Image,
  Dimensions,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { BlurView } from 'expo-blur';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Heart, MessageCircle, Clock, Star } from 'lucide-react-native';
import GlassCard from '@/components/GlassCard';

const { width } = Dimensions.get('window');

// Mock matches data
const mockMatches = [
  {
    id: '1',
    name: 'Emma',
    age: 28,
    image: 'https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg?auto=compress&cs=tinysrgb&w=600',
    lastMessage: 'Hey! How was your weekend?',
    timeAgo: '2h ago',
    isNew: true,
    unreadCount: 2,
  },
  {
    id: '2',
    name: 'Sophia',
    age: 26,
    image: 'https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&w=600',
    lastMessage: 'That restaurant looks amazing!',
    timeAgo: '1d ago',
    isNew: false,
    unreadCount: 0,
  },
  {
    id: '3',
    name: 'Isabella',
    age: 30,
    image: 'https://images.pexels.com/photos/1858175/pexels-photo-1858175.jpeg?auto=compress&cs=tinysrgb&w=600',
    lastMessage: 'Would love to chat more about sustainability!',
    timeAgo: '3d ago',
    isNew: false,
    unreadCount: 1,
  },
  {
    id: '4',
    name: 'Ava',
    age: 27,
    image: 'https://images.pexels.com/photos/1130626/pexels-photo-1130626.jpeg?auto=compress&cs=tinysrgb&w=600',
    lastMessage: 'Thanks for the book recommendation!',
    timeAgo: '1w ago',
    isNew: false,
    unreadCount: 0,
  },
];

const recentMatches = [
  {
    id: '5',
    name: 'Mia',
    image: 'https://images.pexels.com/photos/1542085/pexels-photo-1542085.jpeg?auto=compress&cs=tinysrgb&w=600',
    matchedAt: '2h ago',
    isNew: true,
  },
  {
    id: '6',
    name: 'Charlotte',
    image: 'https://images.pexels.com/photos/1036623/pexels-photo-1036623.jpeg?auto=compress&cs=tinysrgb&w=600',
    matchedAt: '5h ago',
    isNew: true,
  },
  {
    id: '7',
    name: 'Amelia',
    image: 'https://images.pexels.com/photos/1124724/pexels-photo-1124724.jpeg?auto=compress&cs=tinysrgb&w=600',
    matchedAt: '1d ago',
    isNew: false,
  },
];

export default function MatchesScreen() {
  const [selectedTab, setSelectedTab] = useState<'matches' | 'recent'>('matches');

  const renderMatchCard = (match: any) => (
    <TouchableOpacity key={match.id} style={styles.matchCard}>
      <GlassCard style={styles.matchCardInner}>
        <View style={styles.matchInfo}>
          <View style={styles.avatarContainer}>
            <Image source={{ uri: match.image }} style={styles.avatar} />
            {match.isNew && <View style={styles.newIndicator} />}
            {match.unreadCount > 0 && (
              <View style={styles.unreadBadge}>
                <Text style={styles.unreadCount}>{match.unreadCount}</Text>
              </View>
            )}
          </View>
          <View style={styles.matchDetails}>
            <Text style={styles.matchName}>{match.name}</Text>
            <Text style={styles.lastMessage} numberOfLines={1}>
              {match.lastMessage}
            </Text>
          </View>
        </View>
        <View style={styles.matchMeta}>
          <Text style={styles.timeAgo}>{match.timeAgo}</Text>
          <MessageCircle size={16} color="#8B5CF6" />
        </View>
      </GlassCard>
    </TouchableOpacity>
  );

  const renderRecentMatch = (match: any) => (
    <TouchableOpacity key={match.id} style={styles.recentMatchCard}>
      <GlassCard style={styles.recentMatchInner}>
        <Image source={{ uri: match.image }} style={styles.recentAvatar} />
        {match.isNew && <View style={styles.recentNewIndicator} />}
        <Text style={styles.recentMatchName}>{match.name}</Text>
        <Text style={styles.recentMatchTime}>{match.matchedAt}</Text>
      </GlassCard>
    </TouchableOpacity>
  );

  return (
    <LinearGradient colors={['#111827', '#1F2937']} style={styles.container}>
      <SafeAreaView style={styles.safeArea}>
        {/* Header */}
        <View style={styles.header}>
          <Text style={styles.headerTitle}>Matches</Text>
          <TouchableOpacity style={styles.premiumButton}>
            <Star size={20} color="#FFD700" />
            <Text style={styles.premiumText}>Premium</Text>
          </TouchableOpacity>
        </View>

        {/* Tab Selection */}
        <View style={styles.tabContainer}>
          <TouchableOpacity
            style={[styles.tab, selectedTab === 'matches' && styles.activeTab]}
            onPress={() => setSelectedTab('matches')}
          >
            <Text style={[styles.tabText, selectedTab === 'matches' && styles.activeTabText]}>
              Messages
            </Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={[styles.tab, selectedTab === 'recent' && styles.activeTab]}
            onPress={() => setSelectedTab('recent')}
          >
            <Text style={[styles.tabText, selectedTab === 'recent' && styles.activeTabText]}>
              Recent Matches
            </Text>
          </TouchableOpacity>
        </View>

        {/* Content */}
        <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
          {selectedTab === 'matches' ? (
            <View style={styles.matchesList}>
              {mockMatches.map(renderMatchCard)}
            </View>
          ) : (
            <View style={styles.recentMatchesList}>
              <Text style={styles.sectionTitle}>New Matches</Text>
              <Text style={styles.sectionSubtitle}>
                These are your recent matches. Don't forget to say hello!
              </Text>
              <View style={styles.recentGrid}>
                {recentMatches.map(renderRecentMatch)}
              </View>
            </View>
          )}
        </ScrollView>

        {/* Premium Banner */}
        <View style={styles.premiumBanner}>
          <GlassCard style={styles.premiumBannerCard}>
            <LinearGradient
              colors={['rgba(139, 92, 246, 0.2)', 'rgba(236, 72, 153, 0.2)']}
              style={styles.premiumGradient}
            >
              <Heart size={24} color="#EC4899" />
              <Text style={styles.premiumBannerTitle}>See Who Likes You</Text>
              <Text style={styles.premiumBannerSubtitle}>
                Upgrade to see all your admirers
              </Text>
            </LinearGradient>
          </GlassCard>
        </View>
      </SafeAreaView>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  safeArea: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingVertical: 15,
  },
  headerTitle: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#FFFFFF',
  },
  premiumButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(255, 215, 0, 0.1)',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 20,
    borderWidth: 1,
    borderColor: 'rgba(255, 215, 0, 0.3)',
  },
  premiumText: {
    color: '#FFD700',
    fontSize: 14,
    fontWeight: '600',
    marginLeft: 4,
  },
  tabContainer: {
    flexDirection: 'row',
    marginHorizontal: 20,
    marginBottom: 20,
    backgroundColor: 'rgba(31, 41, 55, 0.8)',
    borderRadius: 25,
    padding: 4,
  },
  tab: {
    flex: 1,
    paddingVertical: 12,
    borderRadius: 20,
    alignItems: 'center',
  },
  activeTab: {
    backgroundColor: 'rgba(139, 92, 246, 0.3)',
  },
  tabText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#9CA3AF',
  },
  activeTabText: {
    color: '#FFFFFF',
  },
  content: {
    flex: 1,
  },
  matchesList: {
    paddingHorizontal: 20,
  },
  matchCard: {
    marginBottom: 12,
  },
  matchCardInner: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: 16,
  },
  matchInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  avatarContainer: {
    position: 'relative',
  },
  avatar: {
    width: 60,
    height: 60,
    borderRadius: 30,
    marginRight: 15,
  },
  newIndicator: {
    position: 'absolute',
    top: 2,
    right: 17,
    width: 12,
    height: 12,
    borderRadius: 6,
    backgroundColor: '#EC4899',
    borderWidth: 2,
    borderColor: '#111827',
  },
  unreadBadge: {
    position: 'absolute',
    top: -2,
    right: 12,
    backgroundColor: '#EC4899',
    borderRadius: 10,
    width: 20,
    height: 20,
    justifyContent: 'center',
    alignItems: 'center',
  },
  unreadCount: {
    color: '#FFFFFF',
    fontSize: 12,
    fontWeight: 'bold',
  },
  matchDetails: {
    flex: 1,
  },
  matchName: {
    fontSize: 18,
    fontWeight: '600',
    color: '#FFFFFF',
    marginBottom: 4,
  },
  lastMessage: {
    fontSize: 14,
    color: '#9CA3AF',
  },
  matchMeta: {
    alignItems: 'flex-end',
  },
  timeAgo: {
    fontSize: 12,
    color: '#6B7280',
    marginBottom: 4,
  },
  recentMatchesList: {
    paddingHorizontal: 20,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#FFFFFF',
    marginBottom: 8,
  },
  sectionSubtitle: {
    fontSize: 14,
    color: '#9CA3AF',
    marginBottom: 20,
  },
  recentGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
  recentMatchCard: {
    width: (width - 60) / 3,
    marginBottom: 15,
  },
  recentMatchInner: {
    alignItems: 'center',
    padding: 15,
    position: 'relative',
  },
  recentAvatar: {
    width: 80,
    height: 80,
    borderRadius: 40,
    marginBottom: 8,
  },
  recentNewIndicator: {
    position: 'absolute',
    top: 10,
    right: 10,
    width: 10,
    height: 10,
    borderRadius: 5,
    backgroundColor: '#EC4899',
    borderWidth: 2,
    borderColor: '#111827',
  },
  recentMatchName: {
    fontSize: 14,
    fontWeight: '600',
    color: '#FFFFFF',
    textAlign: 'center',
    marginBottom: 4,
  },
  recentMatchTime: {
    fontSize: 12,
    color: '#9CA3AF',
    textAlign: 'center',
  },
  premiumBanner: {
    margin: 20,
  },
  premiumBannerCard: {
    overflow: 'hidden',
  },
  premiumGradient: {
    padding: 20,
    alignItems: 'center',
  },
  premiumBannerTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#FFFFFF',
    marginTop: 8,
    marginBottom: 4,
  },
  premiumBannerSubtitle: {
    fontSize: 14,
    color: '#D1D5DB',
    textAlign: 'center',
  },
});